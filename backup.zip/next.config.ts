import type { NextConfig } from "next";
import { withSentryConfig } from "@sentry/nextjs";

const wordpressHostname =
  process.env.WORDPRESS_HOSTNAME || "us1.wpdemo.org";
const wordpressUrl = process.env.WORDPRESS_URL;

// Build-time environment validation for production
if (process.env.NODE_ENV === "production") {
  const requiredEnvVars = ["WORDPRESS_URL", "WORDPRESS_WEBHOOK_SECRET"];
  const missingEnvVars = requiredEnvVars.filter(
    (name) => !process.env[name]
  );

  if (missingEnvVars.length > 0) {
    console.error(
      `\n❌ Build failed: Missing required environment variables:`
    );
    missingEnvVars.forEach((name) => console.error(`   → ${name}`));
    console.error(
      "\nPlease set these variables before deploying to production.\n"
    );
    process.exit(1);
  }

  console.log("✅ All required environment variables are set.");
}

const cspValue = [
  `default-src 'self'`,
  `img-src 'self' ${wordpressHostname || ""} woo-dev.local data: blob:`,
  `script-src 'self' 'unsafe-inline'`,
  `style-src 'self' 'unsafe-inline'`,
  `frame-ancestors 'none'`,
  `base-uri 'self'`,
  `form-action 'self'`,
]
  .filter(Boolean)
  .join("; ");

const nextConfig: NextConfig = {
  output: "standalone",
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: wordpressHostname,
        port: "",
        pathname: "/**",
      },
      {
        protocol: "https",
        hostname: "woo-dev.local",
        port: "",
        pathname: "/**",
      },
    ],
    unoptimized: true,
  },
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          {
            key: "Content-Security-Policy",
            value: cspValue,
          },
          {
            key: "X-Content-Type-Options",
            value: "nosniff",
          },
          {
            key: "X-Frame-Options",
            value: "DENY",
          },
          {
            key: "Referrer-Policy",
            value: "strict-origin-when-cross-origin",
          },
          {
            key: "Permissions-Policy",
            value: "camera=(), microphone=(), geolocation=()",
          },
        ],
      },
      {
        source: "/shop/(.*)",
        headers: [
          {
            key: "Cache-Control",
            value: "public, s-maxage=60, stale-while-revalidate=3600",
          },
        ],
      },
      {
        source: "/blog/(.*)",
        headers: [
          {
            key: "Cache-Control",
            value: "public, s-maxage=120, stale-while-revalidate=7200",
          },
        ],
      },
    ];
  },
  async redirects() {
    if (!wordpressUrl) {
      return [];
    }
    const wordpressRedirects = [
      {
        source: "/admin",
        destination: `${wordpressUrl}/wp-admin`,
        permanent: true,
      },
    ];

    return [
      ...wordpressRedirects,
      // WordPress-style permalink redirects from old post routes
      {
        source: "/posts",
        destination: "/blog",
        permanent: true,
      },
      {
        source: "/posts/page/:page",
        destination: "/blog?page=:page",
        permanent: true,
      },
    ];
  },
};

export default withSentryConfig(nextConfig, {
  // Upload source maps to Sentry during build
  sourcemaps: {
    disable: process.env.NODE_ENV === "development",
  },
  // Only upload to Sentry when SENTRY_DSN is configured
  silent: !process.env.SENTRY_DSN && !process.env.NEXT_PUBLIC_SENTRY_DSN,
});