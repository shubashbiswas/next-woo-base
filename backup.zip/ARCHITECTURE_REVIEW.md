# Architecture Review: Headless WordPress + WooCommerce (Next.js 16)

> **Project**: next-woo-base  
> **Stack**: Next.js 16 + React 19 + TypeScript + Tailwind CSS 4 → WordPress REST API + WooCommerce  
> **Target Environment**: Hostinger VPS (Single Node)  
> **Rendering Strategy**: ISR with webhook-based revalidation  

---

## Table of Contents
1. [System Architecture](#1-system-architecture)
2. [Data Flow](#2-data-flow)
3. [Directory Structure](#3-directory-structure)
4. [Key Design Decisions](#4-key-design-decisions)
5. [Security Architecture](#5-security-architecture)
6. [Performance Strategy](#6-performance-strategy)
7. [SEO Implementation](#7-seo-implementation)
8. [Deployment Architecture](#8-deployment-architecture)
9. [Scaling Path](#9-scaling-path)

---

## 1. System Architecture

**Flow**: User Browser (HTTPS via Cloudflare) → Nginx → Next.js Standalone (ISR cache, API routes, Sentry) → WordPress + WooCommerce (Docker + MariaDB)

**Next.js responsibilities**: ISR caching, React `cache()` deduplication, API routes (`/api/revalidate`, `/api/checkout`, `/api/health`), security headers, rate limiting.

**WordPress responsibilities**: Content management, WooCommerce products/orders, REST API, Next Revalidation plugin for cache invalidation.

---

## 2. Data Flow

### Rendering Pipeline

| Stage | Component | Description |
|-------|-----------|-------------|
| **1. Request** | CDN / Nginx | Cloudflare (optional) → Nginx → Next.js |
| **2. Cache Check** | ISR Cache | File-based cache with configurable TTL (default 3600s) |
| **3. Cache Hit** | Serve | Returns cached HTML immediately |
| **4. Cache Miss** | Next.js | Triggers server-side render |
| **5. Data Fetch** | React `cache()` | Deduplicates API calls within render pass |
| **6. WordPress API** | `wordpressFetch` | HTTP connection pooling via `undici` Agent (10 connections) |
| **7. WooCommerce API** | `woocommerceFetch` | HTTP connection pooling via `undici` Agent (10 connections) |
| **8. Cache Store** | ISR | Generated HTML stored in file system for future requests |

### Content Publishing → Cache Invalidation

```
WordPress Editor
(Publish/Update/Delete Post, Page, Product)
        │
        ▼
Next Revalidation Plugin
  • WordPress hooks: save_post, delete_post, transition_post_status, set_object_terms
  • WooCommerce hooks: product CRUD, stock changes, visibility, featured, categories, variations
  • 5s delay (configurable), max 3 retries with exponential backoff
        │
        ▼
POST /api/revalidate
  Headers: x-webhook-secret (shared secret)
  Body: { target: { type, slug, id }, event, timestamp }
        │
        ▼
Revalidation Engine
  1. Rate Limit Check  → 10 req/min/IP (file-based persistence)
  2. Origin Validation → Must match WORDPRESS_URL
  3. Secret Auth       → Must match WORDPRESS_WEBHOOK_SECRET
  4. Content Routing   → revalidateTag() + revalidatePath() per content type
  5. Response          → 200 OK
```

### Cache Invalidation Decisions

| Content Type | Tags Invalidated | Paths Invalidated |
|-------------|-----------------|-------------------|
| Post | `posts`, `posts-page-1`, `post-{id}` | `/blog/{slug}` |
| Page | `pages`, `page-{id}` | `/{slug}` |
| Taxonomy | `categories`, `tags`, `posts-category-{id}`, `posts-tag-{id}` | `/blog/{slug}` |
| Product | `woocommerce`, `products`, `products-page-1`, `product-{id}` | `/shop/{slug}`, `/shop` |
| Stock Change | `product-{id}` | `/shop/{slug}` |
| Category | `woocommerce`, `products` | `/shop` |

---

## 3. Directory Structure

```
├── app/                          # Next.js App Router
│   ├── api/
│   │   ├── checkout/route.ts     # Order creation + Stripe PaymentIntent
│   │   ├── health/route.ts       # System health check
│   │   ├── revalidate/route.ts   # Webhook-based cache invalidation
│   │   └── og/                   # Open Graph image generation
│   ├── shop/                     # Product listing & detail pages
│   ├── cart/                     # Shopping cart page
│   ├── checkout/                 # Checkout flow pages
│   ├── blog/                     # Blog listing & detail pages
│   ├── author/                   # Author archive pages
│   ├── category/                 # Category archive pages
│   └── tag/                      # Tag archive pages
├── components/
│   ├── seo/                      # JSON-LD structured data components
│   │   ├── json-ld.tsx           # Base JsonLd + Organization, WebSite, BreadcrumbList, BlogPosting
│   │   └── product-json-ld.tsx   # Product schema (price, availability, reviews)
│   ├── shop/                     # Shop-specific components
│   │   ├── breadcrumb.tsx        # Visual breadcrumb + JSON-LD
│   │   ├── product-card.tsx      # Product listing card
│   │   ├── cart-context.tsx      # Cart React context (localStorage)
│   │   ├── utils.ts              # Shop utility functions (formatPrice, calculateDiscount, stock status)
│   │   ├── cart-utils.ts         # localStorage persistence utilities
│   │   └── index.ts              # Barrel exports for shop components
│   ├── ui/                       # Reusable UI primitives
│   │   └── image-loading.tsx     # LoadingImage for consistent image rendering
│   └── layout/                   # Layout components (Nav, Footer)
├── lib/
│   ├── wordpress.ts              # WordPress REST API client
│   ├── woocommerce.ts            # WooCommerce REST API client
│   ├── stripe.ts                 # Stripe Payment Intents API
│   ├── rate-limiter.ts           # File-based rate limiter
│   ├── cart.ts                   # Cart persistence utilities
│   ├── sanitize.ts               # HTML sanitization for WP content
│   └── metadata.ts               # SEO metadata generation
├── wordpress/
│   ├── next-revalidate/          # WordPress revalidation plugin
│   └── theme/                    # WordPress theme (headless redirect)
├── sentry.client.config.ts       # Sentry client config
├── sentry.server.config.ts       # Sentry server config
└── next.config.ts                # Next.js configuration + Sentry wrapper
```

---

## 4. Key Design Decisions

### Rendering: ISR with Webhook Revalidation

- **Why**: ISR provides fast TTFB with cached HTML while webhooks ensure content freshness within seconds of publishing
- **Trade-off**: 3600s ISR TTL means stale data survives for up to 1 hour if webhook delivery fails (mitigated by retry mechanism)
- **Future**: Can reduce TTL or switch to fully dynamic rendering if real-time accuracy becomes critical

### API Layer: Graceful Fallbacks

All API fetch functions follow the pattern:
- `wordpressFetch` / `woocommerceFetch` — throws on error (for critical data)
- `wordpressFetchGraceful` / `woocommerceFetchGraceful` — returns fallback on error (for non-critical data)
- `wordpressFetchPaginatedGraceful` — returns empty array on error (for lists)

This prevents cascading failures when WordPress is temporarily unavailable.

### Connection Pooling

Both WordPress and WooCommerce API clients use `undici` Agent with:
- 10 max concurrent connections
- 60s keepalive timeout
- TCP connection reuse across requests

Reduces API latency by 20-40% for pages making multiple API calls.

### Authentication

| Service | Method | Notes |
|---------|--------|-------|
| WooCommerce API | Basic Auth (Authorization header) | Credentials never appear in URLs |
| Webhook Revalidation | Shared secret via `x-webhook-secret` header | Must match between WP plugin and Next.js |
| Checkout CSRF | Origin/Referer validation | Must match `NEXT_PUBLIC_SITE_URL` |

### Error Monitoring (Optional)

Sentry is configured to be **opt-in** — it activates only when `NEXT_PUBLIC_SENTRY_DSN` is set. This means:
- No configuration needed for basic deployments
- Zero overhead when Sentry is not configured
- Full source map upload and error tracking when configured

### Rate Limiting

File-based token bucket with:
- 10 requests per IP per minute (configurable)
- Persisted to `.rate-limit-cache/` directory (survives restarts)
- Works across PM2 cluster mode (shared file system)
- Auto-cleanup of expired records every 5 minutes
- Future: replace with Redis when scaling >2,000 visitors/day

---

## 5. Security Architecture

- **Headers**: CSP (`default-src 'self'`), X-Content-Type-Options `nosniff`, X-Frame-Options `DENY`, Referrer-Policy `strict-origin-when-cross-origin`, Permissions-Policy restricting camera/mic/geolocation.
- **Endpoints**: `/api/revalidate` secured with rate limiting + origin validation + shared secret. `/api/checkout` protected by CSRF origin check + 1MB body limit. `/api/health` intentionally public with no sensitive data.
- **Credentials**: WooCommerce API keys in `Authorization: Basic` header (never in URLs). Webhook secret via constant-time comparison. Stripe key server-side only.

---

## 6. Performance Strategy

**Caching layers**: CDN (optional) → ISR file cache → React `cache()` deduplication → HTTP connection pooling (undici, 10 connections).

**Cache-Control**:
- `/shop/*`: `s-maxage=60, stale-while-revalidate=3600`
- `/blog/*`: `s-maxage=120, stale-while-revalidate=7200`
- `/api/*` and `/health`: `no-store`

---

## 7. SEO Implementation

### Structured Data (JSON-LD)

| Schema Type | Location | Content |
|-------------|----------|---------|
| Organization | Root layout | Site name, URL, description |
| WebSite | Root layout | Site name, search action |
| BreadcrumbList | Shop breadcrumb | Navigation path with URLs |
| Product | Product detail pages | Name, price, availability, SKU, images, aggregate rating |
| BlogPosting | Blog detail pages | Headline, excerpt, author, publish date, featured image |
| WebPage | Static pages | Name, description, publish date |

### Sitemap & RSS

- Dynamic XML sitemap at `/sitemap.xml`
- RSS feed at `/feed.xml/`
- Robots.txt at `/robots.txt`

### Core Web Vitals Considerations

- Font subsetting: Inter font loaded with `latin` subset only
- Image optimization: Next.js `<Image>` component with WordPress remote patterns
- Bundle optimization: Tree-shaken Sentry SDK (no overhead without DSN)
- ISR HTML: Pre-rendered static HTML for immediate paint

---

## 8. Deployment Architecture

**Topology**: Internet → Cloudflare → Nginx (HTTPS termination) → Next.js (port 3000) → WordPress + WooCommerce (Docker + MariaDB 11.4)

**Key notes**:
- WooCommerce REST API requires HTTPS in both production and local development
- Use `NODE_TLS_REJECT_UNAUTHORIZED=0` locally for self-signed certs (remove before production)
- Default authentication via query parameters (`consumer_key` + `consumer_secret`)

**Required env vars**: `WORDPRESS_URL`, `WORDPRESS_HOSTNAME`, `WORDPRESS_WEBHOOK_SECRET`, `WC_CONSUMER_KEY`, `WC_CONSUMER_SECRET`, `NEXT_PUBLIC_SITE_URL`

**Optional env vars**: `ISR_CACHE_TTL`, `STRIPE_SECRET_KEY`, `SENTRY_DSN` / `NEXT_PUBLIC_SENTRY_DSN`, `NODE_TLS_REJECT_UNAUTHORIZED`

---

## 9. Scaling Path

| Stage | Traffic | Architecture Change | Estimated Cost |
|-------|---------|--------------------|---------------:|
| **1** | <500/day | Current single VPS + Cloudflare Free | ~$10-15/month |
| **2** | 500-2,000/day | Replace file-based rate limiter with Redis. Add dedicated Redis instance for shared ISR cache in multi-PM2 mode. | ~$20-30/month |
| **3** | 2,000-5,000/day | Horizontal scaling (2 app instances) + MariaDB read-replica. Add load balancer. | ~$50-80/month |
| **4** | >5,000/day | Full HA: auto-scaling group, managed database, CDN caching rules, Redis cluster. | ~$100+/month |

### Key Bottlenecks to Monitor

1. **WordPress API latency** — Pages making 5+ API calls will see cumulative latency. Mitigate with connection pooling (already implemented) and Redis caching layer.
2. **ISR cache size** — File-based ISR cache can grow large with thousands of products. Monitor disk usage.
3. **Rate limiter persistence** — File-based writes may become I/O-bound at high traffic. Replace with Redis at Stage 2.
4. **Checkout throughput** — Each checkout hits WooCommerce API + Stripe API. Monitor for timeout issues during traffic spikes.